// === Backend (Node.js + Express.js) ===
// Uncomment and run this section separately in a Node.js environment with dependencies installed
/*
const express = require('express');
const axios = require('axios');
const app = express();
const port = 3000;

let jobsData = []; // In-memory storage (MongoDB replacement for simplicity)

app.get('/fetch-jobs', async (req, res) => {
  try {
    const response = await axios.get('https://jsonfakery.com/job-posts');
    jobsData = response.data; // Store fetched jobs
    res.send('Jobs fetched and stored');
  } catch (err) {
    res.status(500).send(err.message);
  }
});

app.get('/jobs', (req, res) => {
  res.json(jobsData); // Serve stored jobs
});

app.listen(port, () => console.log(`Server running on port ${port}`));
// Dependencies: npm install express axios
*/

// === Frontend (React Native) ===
import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

// Create Navigator
const Stack = createStackNavigator();

// Login Screen
const LoginScreen = ({ navigation }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    navigation.navigate('JobListings'); // Simple navigation, no real auth
  };

  return (
    <View style={styles.container}>
      <TextInput
        placeholder="Username"
        value={username}
        onChangeText={setUsername}
        style={styles.input}
      />
      <TextInput
        placeholder="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        style={styles.input}
      />
      <Button title="Login" onPress={handleLogin} />
    </View>
  );
};

// Job Listings Screen
const JobListingsScreen = ({ navigation }) => {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    fetch('http://localhost:3000/jobs') // Replace with your server IP if not local
      .then(res => res.json())
      .then(data => setJobs(data))
      .catch(err => console.error('Fetch error:', err));
  }, []);

  return (
    <View style={styles.container}>
      <FlatList
        data={jobs}
        keyExtractor={item => item.id.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => navigation.navigate('JobDetails', { job: item })}>
            <Text style={styles.jobTitle}>{item.title}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

// Job Details Screen
const JobDetailsScreen = ({ route }) => {
  const { job } = route.params;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{job.title}</Text>
      <Text>{job.description}</Text>
      <Text>Requirements: {job.requirements.join(', ')}</Text>
      <Text>Apply: {job.applicationLink}</Text>
    </View>
  );
};

// Main App
const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="JobListings" component={JobListingsScreen} />
        <Stack.Screen name="JobDetails" component={JobDetailsScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

// Styles
const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, justifyContent: 'center' },
  input: { borderWidth: 1, marginBottom: 10, padding: 8 },
  jobTitle: { fontSize: 18, padding: 10 },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 10 },
});

export default App;